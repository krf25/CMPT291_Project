USE [Cmpt291_GroupProject]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*** Netflix Create tables ***/
Create Table [dbo].[Actor](
	[AID] [int] NOT NULL PRIMARY KEY,
	[Name] [varchar] (255),
	[Gender] [varchar] (255),
	[Age] [int],
	[Rating] [int])
GO

Create Table [dbo].[Movies](
	[MID] [int] NOT NULL PRIMARY KEY,
	[mName] [varchar] (255),
	[mType] [varchar] (255),
	[DistroFee] [float],
	[NumCopies] [int],
	[mRating] [int])
GO

Create Table [dbo].[Participated_IN](
	[AID] [int] NOT NULL,
	[MID] [int] NOT NULL,
	[Role] [varchar] (255),
	PRIMARY KEY (AID, MID),
	FOREIGN KEY (AID) REFERENCES Actor(AID),
	FOREIGN KEY (MID) REFERENCES Movies(MID))
GO

Create Table [dbo].[Copies](
	[CPID] [int] NOT NULL PRIMARY KEY,
	[MID] [int] NOT NULL,
	[mType] [varchar] (255),
	[State] [varchar] (255),
	[Availability] [varchar] (255),
	[ReturnDate] [varchar] (255),
	FOREIGN KEY (MID) REFERENCES Movies(MID))
GO

Create Table [dbo].[Employees](
	[EID] [int] NOT NULL PRIMARY KEY,
	[SSN] [int],
	[LName] [varchar] (255),
	[FName] [varchar] (255),
	[Address] [varchar] (255),
	[City] [varchar] (255),
	[State] [varchar] (255),
	[ZIP] [varchar] (255),
	[Start_Date] [varchar] (255),
	[Hourly_Rate] [int],
	[PhoneNum] [BIGINT],
	[Email] [varchar] (255),
	[password] [varchar] (255))
GO

 Create Table [dbo].[AccountType](
	[TID] [int] NOT NULL PRIMARY KEY,
	[TypeName] [varchar] (255),
	[Cost] [int],
	[MonthlyNum] [int],
	[Concurrently] [int])
GO

Create Table [dbo].[Customer](
	[CID] [int] NOT NULL PRIMARY KEY,
	[LName] [varchar] (255),
	[FName] [varchar] (255),
	[Address] [varchar] (255),
	[City] [varchar] (255),
	[State] [varchar] (255),
	[ZIP] [varchar] (255),
	[Phone] [BIGINT],
	[Email] [varchar] (255),
	[password] [varchar] (255),
	[CreditCardNum] [BIGINT],
	[Rating] [int],
	[TID] [int] NOT NULL,
	[START_Date] [varchar] (255),
	[END_Date] [varchar] (255),
	FOREIGN KEY (TID) REFERENCES AccountType(TID))
GO

Create Table [dbo].[Order](
	[OID] [int] NOT NULL PRIMARY KEY,
	[MID] [int] NOT NULL,
	[CPID] [int] NOT NULL,
	[CID] [int] NOT NULL,
	[EID] [int] NOT NULL,
	[CheckOutDate] [varchar] (255),
	[ReturnDate] [varchar] (255),
	[Returned] [varchar] (255),
	[Rating] [int],
	FOREIGN KEY (MID) REFERENCES Movies(MID),
	FOREIGN KEY (CPID) REFERENCES Copies(CPID),
	FOREIGN KEY (CID) REFERENCES Customer(CID),
	FOREIGN KEY (EID) REFERENCES Employees(EID))
GO

Create Table [dbo].[MovieQueue](
	[QID] [int] NOT NULL PRIMARY KEY,
	[CID] [int] NOT NULL,
	[MID] [int] NOT NULL,
	FOREIGN KEY (CID) REFERENCES Customer(CID),
	FOREIGN KEY (MID) REFERENCES Movies(MID))
GO

-- sets up the the account and others
Insert into AccountType values(0, 'NotActive', 0, 0, 0)
Insert into AccountType values(1, 'Limited', 10, 2, 1)
Insert into AccountType values(2, 'Basic', 15, 1000, 1)
Insert into AccountType values(3, 'Standard', 20, 1000, 2)
Insert into AccountType values(4, 'Premium', 25, 1000, 3)
Insert into Customer values(0, 'Deleted', 'Customer', '', '', '', '', 0, '', '', 0, 0, 0, '1212-12-12', '2012-12-12')
Insert into Employees values(0, 555551234, 'Deleted', 'Employee', '', '', '', '', '2022-11-25', 0, 0, '', '')
Insert into Movies values (0, 'Deleted Movie', 'Tragedy', 0.00, 0, 0)

